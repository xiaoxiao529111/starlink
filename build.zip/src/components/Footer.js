import React, {Component} from 'react';

class Footer extends Component {
    render() {
        return (
            <footer className="footer">
                ©2020 StarLink Tracker. All Rights Reserved. Website Made by XiaoxiaoLi
            </footer>
        );
    }
}

export default Footer;
