export const SAT_API_KEY = "RV4TKY-5BQMZC-FU6JQM-4RRB";

export const STARLINK_CATEGORY = "52";

export const NEARBY_SATELLITE = "rest/v1/satellite/above";

export const WORLD_MAP_URL = "https://unpkg.com/world-atlas@1/world/110m.json";

export const SATELLITE_POSITION_URL = "rest/v1/satellite/positions";

